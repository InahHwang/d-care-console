// CTIBridge/Program.cs
// Windows 서비스 또는 콘솔 앱으로 실행 가능한 CTI Bridge

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.EventLog;
using System.Text;

namespace CTIBridge;

class Program
{
    static async Task Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;

        // 콘솔 모드로 실행 여부 확인
        bool isConsoleMode = args.Contains("--console") || args.Contains("-c") || Environment.UserInteractive;
        bool isInstall = args.Contains("--install") || args.Contains("-i");
        bool isUninstall = args.Contains("--uninstall") || args.Contains("-u");

        // 서비스 설치/제거
        if (isInstall)
        {
            InstallService();
            return;
        }

        if (isUninstall)
        {
            UninstallService();
            return;
        }

        // 콘솔 모드
        if (isConsoleMode && !args.Contains("--service"))
        {
            Console.WriteLine("╔══════════════════════════════════════════════════════════╗");
            Console.WriteLine("║       CTI Bridge - SK Broadband CID 연동 서비스           ║");
            Console.WriteLine("║                    (콘솔 모드)                            ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════╝");
            Console.WriteLine();
            Console.WriteLine("  사용법:");
            Console.WriteLine("    CTIBridge.exe              : 콘솔 모드로 실행");
            Console.WriteLine("    CTIBridge.exe --install    : Windows 서비스로 설치");
            Console.WriteLine("    CTIBridge.exe --uninstall  : Windows 서비스 제거");
            Console.WriteLine();
            Console.WriteLine($"  실행 경로: {AppDomain.CurrentDomain.BaseDirectory}");
            Console.WriteLine($"  시작 시간: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            Console.WriteLine();
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.WriteLine("  종료하려면 Ctrl+C를 누르세요.");
            Console.WriteLine("═══════════════════════════════════════════════════════════");
            Console.WriteLine();
        }

        // 호스트 빌더
        var builder = Host.CreateDefaultBuilder(args)
            .ConfigureServices((context, services) =>
            {
                services.AddHostedService<CTIWorker>();
            })
            .ConfigureLogging((context, logging) =>
            {
                logging.ClearProviders();

                if (isConsoleMode && !args.Contains("--service"))
                {
                    // 콘솔 모드: 콘솔 출력
                    logging.AddConsole();
                    logging.SetMinimumLevel(LogLevel.Information);
                }
                else
                {
                    // 서비스 모드: 이벤트 로그 + 파일 로깅
                    logging.AddEventLog(new EventLogSettings
                    {
                        SourceName = "CTI Bridge",
                        LogName = "Application"
                    });
                    logging.SetMinimumLevel(LogLevel.Information);
                }

                // 파일 로깅 (항상)
                var logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
                if (!Directory.Exists(logPath))
                {
                    Directory.CreateDirectory(logPath);
                }
            });

        // Windows 서비스로 실행 (서비스 모드일 때만)
        if (!isConsoleMode || args.Contains("--service"))
        {
            builder.UseWindowsService(options =>
            {
                options.ServiceName = "CTIBridge";
            });
        }

        var host = builder.Build();
        await host.RunAsync();
    }

    static void InstallService()
    {
        Console.WriteLine("CTI Bridge 서비스 설치 중...");
        Console.WriteLine();

        var exePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CTIBridge.exe");

        try
        {
            // sc.exe를 사용하여 서비스 설치
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = "sc.exe",
                Arguments = $"create CTIBridge binPath= \"\\\"{exePath}\\\" --service\" start= auto DisplayName= \"CTI Bridge Service\"",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using var process = System.Diagnostics.Process.Start(psi);
            process.WaitForExit();

            var output = process.StandardOutput.ReadToEnd();
            var error = process.StandardError.ReadToEnd();

            if (process.ExitCode == 0)
            {
                Console.WriteLine("✓ 서비스 설치 성공!");
                Console.WriteLine();

                // 서비스 설명 추가
                var psi2 = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "sc.exe",
                    Arguments = "description CTIBridge \"SK Broadband CTI 연동 서비스 - 발신자 표시 및 통화기록 관리\"",
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                System.Diagnostics.Process.Start(psi2)?.WaitForExit();

                // 서비스 시작
                Console.WriteLine("서비스 시작 중...");
                var psi3 = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "sc.exe",
                    Arguments = "start CTIBridge",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                using var p3 = System.Diagnostics.Process.Start(psi3);
                p3.WaitForExit();

                if (p3.ExitCode == 0)
                {
                    Console.WriteLine("✓ 서비스 시작됨!");
                }
                else
                {
                    Console.WriteLine("! 서비스 시작 실패 - 수동으로 시작해주세요.");
                }
            }
            else
            {
                Console.WriteLine($"✗ 서비스 설치 실패: {error}");
                Console.WriteLine("  관리자 권한으로 실행해주세요.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ 오류: {ex.Message}");
            Console.WriteLine("  관리자 권한으로 실행해주세요.");
        }
    }

    static void UninstallService()
    {
        Console.WriteLine("CTI Bridge 서비스 제거 중...");
        Console.WriteLine();

        try
        {
            // 서비스 중지
            var psiStop = new System.Diagnostics.ProcessStartInfo
            {
                FileName = "sc.exe",
                Arguments = "stop CTIBridge",
                UseShellExecute = false,
                CreateNoWindow = true
            };
            System.Diagnostics.Process.Start(psiStop)?.WaitForExit();
            System.Threading.Thread.Sleep(2000);

            // 서비스 삭제
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = "sc.exe",
                Arguments = "delete CTIBridge",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using var process = System.Diagnostics.Process.Start(psi);
            process.WaitForExit();

            if (process.ExitCode == 0)
            {
                Console.WriteLine("✓ 서비스 제거 성공!");
            }
            else
            {
                var error = process.StandardError.ReadToEnd();
                Console.WriteLine($"✗ 서비스 제거 실패: {error}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ 오류: {ex.Message}");
        }
    }
}
