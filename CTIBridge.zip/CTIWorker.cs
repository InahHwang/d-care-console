// CTIBridge/CTIWorker.cs
// Windows 서비스로 실행되는 CTI 브릿지 워커

using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace CTIBridge;

public class CTIWorker : BackgroundService
{
    private readonly ILogger<CTIWorker> _logger;
    private readonly HttpClient _http;
    private Encoding _cp949;

    // 설정
    private string _appKey = "zeQ4GBTe/n7Of6S0fd3egUfL4QDxsyc9fJWHwRTGUW4woKsHqFYINVBmFGEnCNyc";
    private string _userId = "dsbrdental";
    private string _password = "ektksqkfms1!";
    private string _nextJsUrl = "https://d-care-console.vercel.app";

    // 상태
    private bool _gotLogin = false;
    private bool _gotSvcInfo = false;
    private bool _needReconnect = false;
    private bool _isConnected = false;

    // 착신녹취 상태
    private bool _isRecordingReady = false;
    private bool _isRecording = false;
    private string _currentCallerId = "";
    private string _currentCalledId = "";
    private DateTime _recordingStartTime;

    #region DLL Imports
    [DllImport("SKB_OpenAPI_IMS.dll", CharSet = CharSet.Ansi)]
    public static extern int IMS_Init(string strAppKey);

    [DllImport("SKB_OpenAPI_IMS.dll", CharSet = CharSet.Ansi)]
    public static extern int IMS_Login(string strUserId, string strPasswd);

    [DllImport("SKB_OpenAPI_IMS.dll", CharSet = CharSet.Ansi)]
    public static extern int IMS_Logout();

    [DllImport("SKB_OpenAPI_IMS.dll", CharSet = CharSet.Ansi)]
    public static extern int IMS_GetEvent(ref _EVTMSG_RAW stEvtMsg);

    [DllImport("SKB_OpenAPI_IMS.dll", CharSet = CharSet.Ansi)]
    public static extern int IMS_Close();

    [DllImport("SKB_OpenAPI_IMS.dll", CharSet = CharSet.Ansi)]
    public static extern int IMS_TermRec_Start();

    [DllImport("SKB_OpenAPI_IMS.dll", CharSet = CharSet.Ansi)]
    public static extern int IMS_TermRec_Stop();

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct _EVTMSG_RAW
    {
        public int nService;
        public int nEvtType;
        public int nResult;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        public byte[] dn1;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        public byte[] dn2;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1024)]
        public byte[] ext;
    }

    public struct EvtMsg
    {
        public int Service;
        public int EvtType;
        public int Result;
        public string Dn1;
        public string Dn2;
        public string ExtInfo;
    }
    #endregion

    #region Constants
    public const int SUCCESS = 0x0000;
    public const int IMS_SVC_CID_NOTIFY = 28;
    public const int IMS_SVC_RING = 7;
    public const int IMS_SVC_CONNECTED = 9;
    public const int EVT_CONNECTED = 0x0101;
    public const int EVT_LOGIN = 0x0104;
    public const int EVT_SERVICE_INFO = 0x0300;
    public const int IMS_SVC_ABS_NOTI = 12;
    public const int IMS_SVC_TERMCALL_START = 10;
    public const int IMS_SVC_TERMCALL_END = 11;
    public const int IMS_SVC_CALL_END = 14;
    public const int IMS_SVC_CALL_STATUS = 15;
    public const int EVT_CALL_STATUS_CHANGE = 0x0304;
    public const int IMS_SVC_TERM_REC = 16;
    public const int EVT_CALL_STATUS = 0x0301;
    public const int EVT_START_SERVICE = 0x0302;
    public const int EVT_STOP_SERVICE = 0x0303;
    public const int EVT_READY_SERVICE = 0x0304;
    public const int EVT_INIT_RECORD = 0x0306;
    public const int EVT_START_RECORD = 0x0307;
    public const int EVT_STOP_RECORD = 0x0308;
    #endregion

    public CTIWorker(ILogger<CTIWorker> logger)
    {
        _logger = logger;
        _http = new HttpClient();

        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        _cp949 = Encoding.GetEncoding(949);
    }

    public override async Task StartAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("CTI Bridge 서비스 시작 중...");
        LoadConfig();
        await base.StartAsync(cancellationToken);
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("CTI Bridge 서비스 종료 중...");

        try { IMS_Logout(); } catch { }
        try { IMS_Close(); } catch { }

        await base.StopAsync(cancellationToken);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("CTI Bridge 서비스 실행 시작");

        // 초기 연결
        if (!await ConnectToCTI())
        {
            _logger.LogError("CTI 초기 연결 실패");
        }

        // 메인 루프
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                // 재연결 필요 시
                if (_needReconnect)
                {
                    _logger.LogWarning("CTI 재연결 시도...");
                    _needReconnect = false;
                    _isConnected = false;

                    try { IMS_Logout(); } catch { }
                    try { IMS_Close(); } catch { }
                    await Task.Delay(2000, stoppingToken);

                    if (await ConnectToCTI())
                    {
                        _logger.LogInformation("CTI 재연결 성공");
                    }
                    else
                    {
                        _logger.LogError("CTI 재연결 실패 - 5초 후 재시도");
                        await Task.Delay(5000, stoppingToken);
                        _needReconnect = true;
                        continue;
                    }
                }

                // 이벤트 폴링
                if (_isConnected)
                {
                    PollEvents();
                }

                await Task.Delay(200, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CTI 이벤트 처리 오류");
                await Task.Delay(1000, stoppingToken);
            }
        }

        _logger.LogInformation("CTI Bridge 서비스 종료됨");
    }

    private void LoadConfig()
    {
        string configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.txt");

        if (File.Exists(configPath))
        {
            try
            {
                foreach (var line in File.ReadAllLines(configPath))
                {
                    var trimmed = line.Trim();
                    if (trimmed.StartsWith("URL="))
                    {
                        _nextJsUrl = trimmed.Substring(4).Trim();
                        _logger.LogInformation("설정 파일에서 URL 로드: {Url}", _nextJsUrl);
                    }
                    else if (trimmed.StartsWith("APP_KEY="))
                    {
                        _appKey = trimmed.Substring(8).Trim();
                    }
                    else if (trimmed.StartsWith("USER_ID="))
                    {
                        _userId = trimmed.Substring(8).Trim();
                    }
                    else if (trimmed.StartsWith("PASSWORD="))
                    {
                        _password = trimmed.Substring(9).Trim();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "설정 파일 읽기 실패");
            }
        }
        else
        {
            // 기본 설정 파일 생성
            try
            {
                File.WriteAllText(configPath,
                    $"URL={_nextJsUrl}\n" +
                    "# 로컬 개발: URL=http://localhost:3000\n" +
                    "# Vercel 배포: URL=https://d-care-console.vercel.app\n");
                _logger.LogInformation("설정 파일 생성됨: {Path}", configPath);
            }
            catch { }
        }
    }

    private async Task<bool> ConnectToCTI()
    {
        _logger.LogInformation("SK CTI API 초기화 중...");

        int rc = IMS_Init(_appKey);
        if (rc != SUCCESS)
        {
            _logger.LogError("CTI 초기화 실패 (코드: 0x{Code:X})", rc);
            return false;
        }
        _logger.LogInformation("CTI 초기화 성공");

        // 로그인 시도 (최대 3회)
        for (int attempt = 1; attempt <= 3; attempt++)
        {
            if (attempt > 1)
            {
                _logger.LogInformation("로그인 {Attempt}차 재시도...", attempt);
                try { IMS_Logout(); } catch { }
                await Task.Delay(1500);
            }

            _gotLogin = false;
            _gotSvcInfo = false;

            rc = IMS_Login(_userId, _password);
            if (rc != SUCCESS)
            {
                _logger.LogWarning("로그인 요청 실패 (코드: 0x{Code:X})", rc);
                continue;
            }

            await Task.Delay(200);

            if (await WaitLoginAndSvcInfo(60000))
            {
                _logger.LogInformation("CTI 로그인 성공");
                _isConnected = true;
                return true;
            }
        }

        _logger.LogError("CTI 로그인 실패");
        return false;
    }

    private async Task<bool> WaitLoginAndSvcInfo(int maxWaitMs)
    {
        var cts = new CancellationTokenSource(maxWaitMs);

        // 로그인 응답 대기
        while (!cts.IsCancellationRequested && !_gotLogin)
        {
            PollEvents();
            await Task.Delay(150);
        }

        if (!_gotLogin) return false;

        // 서비스 정보 대기 (5초)
        var cts2 = new CancellationTokenSource(5000);
        while (!cts2.IsCancellationRequested && !_gotSvcInfo)
        {
            PollEvents();
            await Task.Delay(150);
        }

        return true;
    }

    private void PollEvents()
    {
        try
        {
            var raw = new _EVTMSG_RAW
            {
                dn1 = new byte[32],
                dn2 = new byte[32],
                ext = new byte[1024]
            };

            int r = IMS_GetEvent(ref raw);
            if (r != SUCCESS) return;

            var evt = ParseRaw(raw);
            if (!HasPayload(evt)) return;

            // 연결 끊김 감지
            if (evt.Result == 0x8000 || (evt.Service == 30 && evt.EvtType == 0x102 && evt.Result != SUCCESS))
            {
                _logger.LogWarning("CTI 연결 끊김 감지");
                _needReconnect = true;
                return;
            }

            // 이벤트 처리
            ProcessEvent(evt);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "이벤트 폴링 오류");
        }
    }

    private void ProcessEvent(EvtMsg evt)
    {
        if (evt.EvtType == EVT_CONNECTED)
        {
            _logger.LogInformation("서버 연결됨");
        }
        else if (evt.EvtType == EVT_LOGIN)
        {
            _logger.LogInformation("로그인 완료");
            _gotLogin = true;
        }
        else if (evt.EvtType == EVT_SERVICE_INFO)
        {
            _gotSvcInfo = true;
        }
        else if (evt.Service == IMS_SVC_RING || evt.Service == IMS_SVC_CID_NOTIFY)
        {
            if (!string.IsNullOrEmpty(evt.Dn1))
            {
                _logger.LogInformation("📞 전화 수신: {Caller} → {Called}", evt.Dn1, evt.Dn2);
                _ = SendToNextJS(evt.Dn1, evt.Dn2);
                _ = SendCallLogEvent("ring", evt.Dn1, evt.Dn2, evt.ExtInfo);
            }
        }
        else if (evt.Service == IMS_SVC_CONNECTED)
        {
            if (!string.IsNullOrEmpty(evt.Dn1))
            {
                _logger.LogInformation("📱 통화 연결: {Caller}", evt.Dn1);
                _ = SendCallLogEvent("start", evt.Dn1, evt.Dn2, evt.ExtInfo);
            }
        }
        else if (evt.Service == IMS_SVC_TERMCALL_START)
        {
            if (!string.IsNullOrEmpty(evt.Dn1))
            {
                _logger.LogInformation("📱 통화 시작: {Caller}", evt.Dn1);
                _ = SendCallLogEvent("start", evt.Dn1, evt.Dn2, evt.ExtInfo);
            }
        }
        else if (evt.Service == IMS_SVC_TERMCALL_END)
        {
            string callerNum = evt.Dn2;
            string calledNum = evt.Dn1;
            if (!string.IsNullOrEmpty(callerNum))
            {
                _logger.LogInformation("📴 통화 종료: {Caller}", callerNum);
                _ = SendCallLogEvent("end", callerNum, calledNum, evt.ExtInfo);
            }
        }
        else if (evt.Service == IMS_SVC_CALL_END)
        {
            if (!string.IsNullOrEmpty(evt.Dn1))
            {
                _logger.LogInformation("📴 통화 종료: {Caller}", evt.Dn1);
                _ = SendCallLogEvent("end", evt.Dn1, evt.Dn2, evt.ExtInfo);
            }
        }
        else if (evt.Service == IMS_SVC_ABS_NOTI)
        {
            if (!string.IsNullOrEmpty(evt.Dn1))
            {
                _logger.LogInformation("❌ 부재중: {Caller}", evt.Dn1);
                _ = SendCallLogEvent("missed", evt.Dn1, evt.Dn2, evt.ExtInfo);
            }
        }
        else if (evt.Service == IMS_SVC_CALL_STATUS && evt.EvtType == EVT_CALL_STATUS_CHANGE)
        {
            string extLower = (evt.ExtInfo ?? "").ToLower();
            string callerNum = evt.Dn2;
            string calledNum = evt.Dn1;

            if (extLower.Contains("called") || extLower.Contains("answer") || extLower.Contains("connect"))
            {
                _logger.LogInformation("📱 통화 연결: {Caller}", callerNum);
                _ = SendCallLogEvent("start", callerNum, calledNum, evt.ExtInfo);
            }
            else if (extLower.Contains("release") || extLower.Contains("disconnect") || extLower.Contains("end") || extLower.Contains("bye"))
            {
                _logger.LogInformation("📴 통화 종료: {Caller}", callerNum);
                _ = SendCallLogEvent("end", callerNum, calledNum, evt.ExtInfo);
            }
        }
        else if (evt.Service == IMS_SVC_TERM_REC)
        {
            ProcessTermRecEvent(evt);
        }
    }

    private void ProcessTermRecEvent(EvtMsg evt)
    {
        switch (evt.EvtType)
        {
            case EVT_READY_SERVICE:
                _isRecordingReady = true;
                _currentCallerId = evt.Dn1;
                _currentCalledId = evt.Dn2;
                _logger.LogInformation("🎙️ 착신녹취 준비: {Caller} → {Called}", evt.Dn1, evt.Dn2);

                int startResult = IMS_TermRec_Start();
                if (startResult == SUCCESS)
                {
                    _logger.LogInformation("녹취 시작 요청 성공");
                    _recordingStartTime = DateTime.Now;
                }
                else
                {
                    _logger.LogWarning("녹취 시작 실패 (코드: 0x{Code:X})", startResult);
                    _isRecordingReady = false;
                }
                break;

            case EVT_START_RECORD:
                if (evt.Result == SUCCESS)
                {
                    _isRecording = true;
                    _logger.LogInformation("🔴 녹취 시작: {FileName}", evt.ExtInfo);
                }
                break;

            case EVT_STOP_RECORD:
                _isRecording = false;
                _isRecordingReady = false;
                int duration = (int)(DateTime.Now - _recordingStartTime).TotalSeconds;
                _logger.LogInformation("⏹️ 녹취 완료: {FileName} ({Duration}초)", evt.ExtInfo, duration);
                _ = SendRecordingComplete(_currentCallerId, _currentCalledId, evt.ExtInfo, duration);
                _currentCallerId = "";
                _currentCalledId = "";
                break;

            case EVT_STOP_SERVICE:
                _isRecording = false;
                _isRecordingReady = false;
                _logger.LogInformation("녹취 서비스 종료");
                break;
        }
    }

    private EvtMsg ParseRaw(_EVTMSG_RAW raw)
    {
        return new EvtMsg
        {
            Service = raw.nService,
            EvtType = raw.nEvtType,
            Result = raw.nResult,
            Dn1 = BytesToAnsiString(raw.dn1),
            Dn2 = BytesToAnsiString(raw.dn2),
            ExtInfo = BytesToAnsiString(raw.ext)
        };
    }

    private string BytesToAnsiString(byte[] buf)
    {
        if (buf == null || buf.Length == 0) return "";
        int len = Array.IndexOf<byte>(buf, 0);
        if (len < 0) len = buf.Length;
        if (len == 0) return "";
        return _cp949.GetString(buf, 0, len).Trim();
    }

    private bool HasPayload(EvtMsg e)
    {
        return e.Service != 0 || e.EvtType != 0 || e.Result != 0 ||
               !string.IsNullOrEmpty(e.Dn1) || !string.IsNullOrEmpty(e.Dn2) ||
               !string.IsNullOrEmpty(e.ExtInfo);
    }

    private async Task SendToNextJS(string callerNumber, string calledNumber)
    {
        try
        {
            var payload = new
            {
                callerNumber,
                calledNumber,
                timestamp = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffzzz")
            };

            var json = JsonSerializer.Serialize(payload);
            var response = await _http.PostAsync(
                $"{_nextJsUrl}/api/cti/incoming-call",
                new StringContent(json, Encoding.UTF8, "application/json")
            );

            if (response.IsSuccessStatusCode)
            {
                _logger.LogDebug("Next.js 전송 성공");
            }
            else
            {
                _logger.LogWarning("Next.js 전송 실패: HTTP {StatusCode}", (int)response.StatusCode);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Next.js 전송 오류");
        }
    }

    private async Task SendCallLogEvent(string eventType, string callerNumber, string calledNumber, string extInfo)
    {
        try
        {
            var payload = new
            {
                eventType,
                callerNumber,
                calledNumber,
                timestamp = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffzzz"),
                extInfo
            };

            var json = JsonSerializer.Serialize(payload);
            var response = await _http.PostAsync(
                $"{_nextJsUrl}/api/call-logs",
                new StringContent(json, Encoding.UTF8, "application/json")
            );

            if (response.IsSuccessStatusCode)
            {
                _logger.LogDebug("통화기록 저장 성공");
            }
            else
            {
                _logger.LogWarning("통화기록 저장 실패: HTTP {StatusCode}", (int)response.StatusCode);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "통화기록 저장 오류");
        }
    }

    private async Task SendRecordingComplete(string callerNumber, string calledNumber, string recordingInfo, int durationSeconds)
    {
        try
        {
            bool isUrl = recordingInfo.StartsWith("http://") || recordingInfo.StartsWith("https://");

            var payload = new
            {
                callerNumber,
                calledNumber,
                recordingFileName = isUrl ? Path.GetFileName(recordingInfo) : recordingInfo,
                recordingUrl = isUrl ? recordingInfo : (string)null,
                duration = durationSeconds,
                timestamp = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffzzz")
            };

            var json = JsonSerializer.Serialize(payload);
            var response = await _http.PostAsync(
                $"{_nextJsUrl}/api/call-analysis/recording",
                new StringContent(json, Encoding.UTF8, "application/json")
            );

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation("녹취 정보 전송 성공");
            }
            else
            {
                _logger.LogWarning("녹취 정보 전송 실패: HTTP {StatusCode}", (int)response.StatusCode);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "녹취 정보 전송 오류");
        }
    }
}
